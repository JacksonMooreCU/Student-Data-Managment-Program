
#ifndef STUDENT_PROTOTYPES
#define STUDENT_PROTOTYPES

#include "struct.h"

void printStudent(struct person *person);
void searchStudentFamilyName(struct person *person);
void printStudents(struct person *person,char lastName[16]);
void studentRecords(struct person *person);
#endif
