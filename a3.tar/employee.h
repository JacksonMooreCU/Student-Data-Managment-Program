
#ifndef EMPLOYEE_PROTOTYPES
#define EMPLOYEE_PROTOTYPES

#include "struct.h"

void printEmployee(struct person *person);
void printEmployees(struct person *person);
void employeeRecords(struct person *person);
#endif
